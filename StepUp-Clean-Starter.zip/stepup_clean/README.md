# StepUp clean Android starter

A minimal offline step counter starter. It uses Android's built-in step counter sensor and requests Activity Recognition permission on Android 10+.


## Build on GitHub Actions
1. Upload the **contents** of this project folder to a new private GitHub repository (not this ZIP itself).
2. Ensure `.github/workflows/android-build.yml` is present.
3. Open Actions tab and run **Android Build** using Run workflow.
4. When successful, download the `StepUp-debug-apk` artifact to install/test.

This is a starter build, not a Play Store release. A release bundle and signing setup are still required.
