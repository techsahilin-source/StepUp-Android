package com.sahil.stepup

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private lateinit var stepsView: TextView
    private var steps = 0
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15,18,28); window.navigationBarColor = Color.rgb(15,18,28)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(Color.rgb(15,18,28)) }
        val title=TextView(this).apply { text="STEPUP"; textSize=28f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        stepsView=TextView(this).apply { text="0"; textSize=64f; setTextColor(Color.rgb(87,220,170)); gravity=Gravity.CENTER; setPadding(0,40,0,12) }
        val label=TextView(this).apply { text="steps today"; textSize=18f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER }
        val goal=TextView(this).apply { text="Daily goal  ·  8,000 steps"; textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,36,0,0) }
        root.addView(title); root.addView(stepsView); root.addView(label); root.addView(goal); setContentView(root)
        sensorManager=getSystemService(SENSOR_SERVICE) as SensorManager; stepSensor=sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),101)
    }
    override fun onResume(){ super.onResume(); stepSensor?.let { sensorManager.registerListener(this,it,SensorManager.SENSOR_DELAY_NORMAL) } }
    override fun onPause(){ super.onPause(); sensorManager.unregisterListener(this) }
    override fun onSensorChanged(event:SensorEvent){ if(event.sensor.type==Sensor.TYPE_STEP_COUNTER){ steps=event.values[0].toInt(); stepsView.text=steps.toString() } }
    override fun onAccuracyChanged(sensor:Sensor, accuracy:Int){}
}
